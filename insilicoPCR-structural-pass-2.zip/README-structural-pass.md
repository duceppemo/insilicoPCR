# Structural modernization pass 2

This pass removes the modern pipeline's dependency on the legacy `CommandMethods` utility hub.

## What changed

- `PrimerService` now owns primer FASTA parsing, validation, degenerate-base expansion, and `primer_tmp.fasta` staging.
- `SampleRepository` now loads samples directly from `SequenceFileUtils`.
- `BlastDatabaseBuilder` now invokes `makeblastdb` directly through `ProcessRunner`.
- `BlastRunner` now uses `BlastTsv` instead of `CommandMethods.addHeaderToTSV`.
- `ReportGenerator` now delegates to dedicated pipeline services:
  - `ContigService`
  - `BlastReportParser`
  - `ConsolidatedReportWriter`
  - `QaLogWriter`
- `CommandMethods` is intentionally left in place for GUI/backward compatibility.

## Next safe deletion target

After this pass compiles and the GUI still runs, audit usages of `CommandMethods`:

```bash
git grep "CommandMethods\."
```

Anything still used only by pipeline should now be gone. Remaining calls are likely GUI compatibility methods.
