#!/usr/bin/env bash
set -euo pipefail

ROOT="${1:-.}"
SRC="$ROOT/src/main/java/ca/canada/inspection/pipeline"
mkdir -p "$SRC"
cp -R "$(dirname "$0")/src/main/java/ca/canada/inspection/pipeline/." "$SRC/"

echo "Applied structural modernization pass 2."
echo "Run: mvn clean test && mvn clean package"
